﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathematicalFunctionsSearchingSorting
{
    public static class Searching
    {
        #region Linear Search

        /// <summary>
        /// 'LinearSearch' Overload 1
        /// Uses the linear search algorithm to search for 'key' in a list of double values 'l'.
        /// Returns the the index of the first occurrence of 'key' if 'key' exists in 'l'.
        /// Otherwise, -1 is returned.
        /// </summary>
        /// 
        public static int LinearSearch(List<double> l, double key)
        {
            int index = -1, i = 0;

            while (i < l.Count && l[i] != key)
            {
                i++;
            }

            // The value of 'i' can only equal 'l.Count' if 'key' was not found
            if (i < l.Count)
            {
                index = i;
            }

            return index;
        }

        /// <summary>
        /// 'LinearSearch' Overload 2
        /// Uses the linear search algorithm to search for 'key' in an array of double values 'a'.
        /// Returns the the index of the first occurrence of 'key' if 'key' exists in 'a'.
        /// Otherwise, -1 is returned.
        /// </summary>
        /// 

        public static int LinearSearch(double[] a, double key)
        {
            int index = -1;

            // Insert your code here

            return index;
        }

        #endregion

        #region Binary Search
        
        /// <summary>
        /// 'BinarySearch' Overload 1
        /// Uses the binary search algorithm to search for 'key' in a list of double values 'l'.
        /// Returns the the index of the first occurrence of 'key' if 'key' exists in 'l'.
        /// Otherwise, -1 is returned.
        /// </summary>

        public static int BinarySearch(List<double> l, double key)
        {
            int index = -1;

            // Insert your code here

            return index;
        }

        /// <summary>
        /// 'BinarySearch' Overload 2
        /// Uses the binary search algorithm to search for 'key' in an array of double values 'a'.
        /// Returns the the index of the first occurrence of 'key' if 'key' exists in 'a'.
        /// Otherwise, -1 is returned.
        /// </summary>

        public static int BinarySearch(double[] a, double key)
        {
            int index = -1;

            // Insert your code here

            return index;
        }
        #endregion
    }

}
